CASE_DIR=$1
rm -rf ${CASE_DIR}
mkdir ${CASE_DIR}

