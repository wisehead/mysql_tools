
rm -rf /ssd/mysql/mysql/var/*;rm -rf /home/mysql/mysql/var/*;rm -rf /nvram/mysql/var/*;rm -rf /home/mysql/mysql/log/*

